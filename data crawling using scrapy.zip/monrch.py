import scrapy
from urllib.parse import urljoin
import csv

class monarchSpider(scrapy.Spider):
    name = "monarchdental"
    allowed_domains = ["www.monarchdental.com"]
    start_urls = ["https://www.monarchdental.com/dentist-near-me/"]
    count = 0

    custom_settings = {
        'DOWNLOAD_DELAY': 2,
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse, dont_filter=True)

    def parse(self, response):
        if response.status == 400:
            self.logger.warning(f"Received 400 Bad Request for URL: {response.url}")
            return

        state_urls = response.xpath('//section[@class="offices-search container"]/div/ul/li/a/@href').getall()
        for state_url in state_urls:
            absolute_state_url = urljoin(response.url, state_url)
            yield scrapy.Request(absolute_state_url, callback=self.parse_state, dont_filter=True)

    def parse_state(self, response):
        if response.status == 400:
            self.logger.warning(f"Received 400 Bad Request for URL: {response.url}")
            return

        city_urls = response.xpath('//div[@class="office marker"]/h4/a/@href').getall()
        for city_url in city_urls:
            absolute_city_url = urljoin(response.url, city_url)
            yield scrapy.Request(absolute_city_url, callback=self.parse_store, dont_filter=True)

    def parse_store(self, response):
        if response.status == 400:
            self.logger.warning(f"Received 400 Bad Request for URL: {response.url}")
            return

        final_data = {}
        self.count += 1
        final_data['ref'] = str(self.count)
        final_data["address1"] = response.xpath('//div[@class="office-detail-box"]/address/text()[1]').get(default='')
        final_data["address2"] = response.xpath('//div[@class="office-detail-box"]/address/text()[2]').get(default='')

        with open('dentaldreams.csv', mode='a', newline='') as csv_file:
            fieldnames = ['ref', 'address1', 'address2']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            if csv_file.tell() == 0:
                writer.writeheader()
            writer.writerow(final_data)

        yield final_data
