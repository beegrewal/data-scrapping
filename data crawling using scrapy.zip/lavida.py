import scrapy
import csv

class lSpider(scrapy.Spider):
    name = "lavida"
    brand_name = 'LaVida massage'
    spider_type = 'chain'
    spider_chain_id = '1504'
    user = 'useyouremail@hotmail.com'
    allowed_domains = ["lavidamassage.com"]
    start_urls = ["https://lavidamassage.com/store-locator/"]
    count = 0

    custom_settings = {
        'DOWNLOAD_DELAY': 2
    }

    headers = {
        'authority': 'www.lavidamassage.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Google Chrome";v="116"',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse)

    def parse(self, response):
        # Extract the address data directly from the page
        finalData = {}
        self.count += 1
        finalData['ref'] = str(self.count)
        finalData["address1"] = response.xpath('//div[@class="addr-loc"]/ul/li[contains(text(), "Address:")]/following-sibling::li/text()').get(default='')


        with open('lavida.csv', mode='a', newline='') as csv_file:
            fieldnames = ['ref', 'address1']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            if csv_file.tell() == 0:
                writer.writeheader()
            writer.writerow(finalData)

        yield finalData
