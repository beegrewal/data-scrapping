import requests
from lxml import html
import csv
from bs4 import BeautifulSoup
import csv
# URL of the webpage to scrape
url = "https://www.cardinalhealth.com/en/product-solutions/pharmaceutical-products/nuclear-medicine/radiopharmacy-locations.html"


def scrape_radiopharmacy_locations(url):
    # Send an HTTP GET request to the URL
    response = requests.get(url)

    # Check if the request was successful
    if response.status_code == 200:
        # Parse the HTML content of the page using lxml
        tree = html.fromstring(response.content)

        # Find all location elements using a common XPath expression
        locations = tree.xpath('//div[contains(@class, "com_locator_address")]')

        # Open a CSV file to write the data
        with open('radiopharmacy_locations.csv', 'w', newline='') as csvfile:
            # Create a CSV writer object
            csv_writer = csv.writer(csvfile)

            # Loop through the locations and extract the information
            for location in locations:
                # Extract the data you need from each location element
                location_name = location.xpath('.//span[@class="ml_tagtext"]/text()')[0]
                location_address = location.xpath('.//span[@class="line_item address"]/text()')[0]
                location_city = location.xpath('.//span[@class="line_item city"]/text()')[0]
                location_state = location.xpath('.//span[@class="line_item state"]/text()')[0]
                location_postalcode = location.xpath('.//span[@class="line_item postalcode"]/text()')[0]

                # Write the extracted data to the CSV file
                csv_writer.writerow([location_name, location_address, location_city, location_state, location_postalcode])

        print("Data has been written to radiopharmacy_locations.csv")
    else:
        print(f"Failed to retrieve the webpage. Status code: {response.status_code}")

if __name__ == "__main__":
    scrape_radiopharmacy_locations(url)
