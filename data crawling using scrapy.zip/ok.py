import requests
from bs4 import BeautifulSoup
import csv

# Function to get store addresses from a city URL
def get_store_addresses(city_url):
    response = requests.get(city_url)
    soup = BeautifulSoup(response.content, 'html.parser')
    addresses = []

    # Find all store address elements
    address_elements = soup.find_all('div', class_='store-address')
    
    for address_element in address_elements:
        address = address_element.get_text(strip=True)
        addresses.append(address)

    return addresses

# Function to scrape and save data for a specific state
def scrape_and_save_state(state_code):
    state_url = f"https://www.brueggers.com/us/{state_code}"
    city_links = get_city_links(state_url)

    with open(f"{state_code}_brueggers_addresses.csv", mode='w', newline='', encoding='utf-8') as csv_file:
        fieldnames = ['Address']
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()

        for city_link in city_links:
            addresses = get_store_addresses(city_link)
            for address in addresses:
                writer.writerow({'Address': address})

# Function to get city links from a state URL
def get_city_links(state_url):
    response = requests.get(state_url)
    soup = BeautifulSoup(response.content, 'html.parser')
    city_links = []

    # Find all city links
    for city in soup.find_all('a', class_='c-directory-list-link'):
        city_links.append(city['href'])
    
    return city_links

if __name__ == "__main__":
    locations_url = "https://locations.brueggers.com/us"
    state_codes = ["ak", "al"]  # Replace with the state codes you want to scrape

    for state_code in state_codes:
        scrape_and_save_state(state_code)
