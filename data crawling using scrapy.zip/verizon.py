import scrapy
from urllib.parse import urljoin
import csv

class VerizonSpider(scrapy.Spider):
    name = "verizone"
    allowed_domains = ["www.verizon.com"]
    start_urls = ["https://www.verizon.com/stores/"]
    count = 0

    custom_settings = {
        'DOWNLOAD_DELAY': 1
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse, dont_filter=True)

    def parse(self, response):
        state_urls = response.xpath('//a[@class="u-fontDisplay u-text--xs16 u-marginBottom--xs20 u-colorSecondary u-displayBlock u-textDecorationNone"]/@href').getall()
        for state_url in state_urls:
            absolute_state_url = urljoin(response.url, state_url)
            yield scrapy.Request(absolute_state_url, callback=self.parse_state, dont_filter=True)

    def parse_state(self, response):
        city_urls = response.xpath('//a[@class="StyledAnchor-VDS__sc-9x52p1-2 gnineg"]/@href').getall()
        for city_url in city_urls:
            absolute_city_url = urljoin(response.url, city_url)
            yield scrapy.Request(absolute_city_url, callback=self.parse_city, dont_filter=True)

    def parse_location(self, response):
        location_urls = response.xpath('//button[@id="slSearch-StoreDetailBtn0Id"]/span[2]').getall()
        for location_url in location_urls:
            absolute_location_url = urljoin(response.url, location_url)
            yield scrapy.Request(absolute_location_url, callback=self.parse_location, dont_filter=True)

    def parse_city(self, response):
        store_urls = response.xpath('//div[@class="p-3"]').getall()
        for store_url in store_urls:
            absolute_store_url = urljoin(response.url, store_url)
            yield scrapy.Request(absolute_store_url, callback=self.parse_store, dont_filter=True)

    def parse_store(self, response):
        final_data = {}
        self.count += 1
        final_data['ref'] = str(self.count)
        final_data['name'] = response.xpath('//h2[@id="storeDetails-NamesTitleId"]/text()').get(default='')
        
        # Extracting the address fields
        address1 = response.xpath('//span[@id="storeDetails-AddressLinkId"]/text()').get(default='')
        address2 = response.xpath('//span[@id="storeDetails-ZipCodeLinkId"]/text()').get(default='')
        final_data["address1"] = address1.strip() if address1 else ''
        final_data["address2"] = address2.strip() if address2 else ''
        
        # # Extracting state and zipcode
        # state_zipcode = response.xpath('//span[@class="c-address-postal-code"]/text()').get('')
        # state_zipcode_parts = state_zipcode.split()
        # if len(state_zipcode_parts) >= 2:
        #     final_data["state"] = state_zipcode_parts[-2]
        #     final_data["zipcode"] = state_zipcode_parts[-1]
        # else:
        #     final_data["state"] = ''
        #     final_data["zipcode"] = ''

        with open('verizon.csv', mode='a', newline='') as csv_file:
            fieldnames = ['ref', 'name', 'address1', 'address2']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            if csv_file.tell() == 0:
                writer.writeheader()
            writer.writerow(final_data)

        yield final_data
