import scrapy
import csv

class woodSpider(scrapy.Spider):
    name = "woodhouse"
    brand_name = 'WOODHOUSE'
    spider_type = 'chain'
    spider_chain_id = '1509'
    user = 'shivnakurmishra@hotmail.com'
    allowed_domains = ["woodhousespas.com"]
    start_urls = ["https://locations.woodhousespas.com/"]
    count = 0

    custom_settings = {
        'DOWNLOAD_DELAY': 2
    }

    headers = {
        'authority': 'www.woodhousespas.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Google Chrome";v="116"',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse)

    def parse(self, response):
        # Extract the links to individual locations
        location_links = response.xpath('//div[@class="Teaser-links"]/div[2]/a/@href').getall()
        for location_link in location_links:
            yield response.follow(location_link, callback=self.parse_location)

    def parse_location(self, response):
        finalData = {}
        self.count += 1
        finalData['ref'] = str(self.count)
        # finalData["city"] = response.xpath('//span[@itemprop="addressLocality"]/text()').get(default='')
        finalData["address1"] = response.xpath('//address[@id="address"]/div[1]/span/text()').get(default='')
        finalData["state"] = response.xpath('//address[@id="address"]/div[2]/abbr/text()').get(default='')
        finalData["locality"] = response.xpath('//address[@id="address"]/div[2]/span[1]/text()').get(default='')
        # finalData["lat"] = response.xpath('//main[@id="main"]/div[2]/div[2]/div/div/div[1]/div[5]/div[1]/div[4]/span/meta[1]/@content').get(default='')
        # finalData["long"] = response.xpath('//main[@id="main"]/div[2]/div[2]/div/div/div[1]/div[5]/div[1]/div[4]/span/meta[2]/@content').get(default='')
        finalData["zipcode"] = response.xpath('//address[@id="address"]/div[2]/span[2]/text()').get(default='')
     
        with open('woodhouse.csv', mode='a', newline='') as csv_file:
            fieldnames = ['ref', 'address1', 'state', 'locality', 'lat', 'long', 'zipcode']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            if csv_file.tell() == 0:
                writer.writeheader()
            writer.writerow(finalData)

        yield finalData
